# THE MARQUE — Hybrid Luxury Travel Site

A Next.js (App Router) + TailwindCSS site designed in a Romantic Modern Editorial style inspired by Belmond + Four Seasons.
It includes:
- Hero landing with luxe typography/colors for UHNW appeal
- “Experiences from Around the World” (blog) with up to 4 images + ~350 words
- Interactive SVG map with pins linking to Experiences
- Membership page (annual concierge model) + Crypto Travel page
- Preferred Partners page with *hover popups* for perks
- Footer with TICO number + partner logos
- Unprotected `/admin` to edit posts locally and export `content/posts.json`
- SEO metadata, robots.txt, sitemap.xml
- Vercel-ready, static export enabled

## Quick Start

### 1) Install
```bash
# using npm
npm i
# or pnpm
pnpm i
```

### 2) Develop
```bash
npm run dev
```

### 3) Build & Export (for Vercel static or any static host)
```bash
npm run build
# output is in /out; Vercel also supports static export
```

> Tip: For ISR/SSR, remove `output: 'export'` in `next.config.js` and deploy to Vercel as a Next.js app.

### 4) Update Content
- Edit `content/posts.json` (supports up to 4 images, 350-ish words).
- Add images to `/public/...`; reference with absolute path (e.g. `/samples/amalfi1.jpg`).
- Edit partner perks in `content/partners.json`.
- Update footer TICO number in `app/layout.js` (search for `TICO #`).

### Admin (Local Drafts Only)
The `/admin` page stores edits in **localStorage**. Use **Export** to download `posts.json` then replace the file in `content/posts.json` within your repo.

### SEO
Basic OpenGraph/Twitter tags are defined in `app/layout.js`. robots.txt and sitemap.xml are included.

### Branding
- Colors: deep navy (`#0F172A`), champagne (`#D4C6A7`), parchment (`#F7F3ED`)
- Typography: display serif headings, modern sans body
- Cards: rounded 2xl + soft luxe shadow

---

© THE MARQUE
