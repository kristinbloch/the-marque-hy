/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: { unoptimized: true }, // allow next export
  output: 'export', // static export for easy Vercel/GitHub Pages too
};
module.exports = nextConfig;
