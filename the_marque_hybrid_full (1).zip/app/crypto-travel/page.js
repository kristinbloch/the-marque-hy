export const metadata = {
  title: 'Crypto Travel — THE MARQUE'
}
export default function CryptoTravelPage(){
  return (
    <div className="container-luxe">
      <div className="max-w-4xl mx-auto mt-12 card p-8">
        <div className="kicker">Payments</div>
        <h1 className="text-4xl font-display mt-3">Crypto Travel</h1>
        <p className="text-ash mt-4">For clients who prefer digital assets, we support secure cryptocurrency payments for eligible services. Transactions are quoted in real‑time, with compliance checks and receipts provided in both fiat and crypto terms.</p>
        <ul className="list-disc list-inside text-ash mt-4">
          <li>BTC, ETH, and stablecoins via a vetted payment processor</li>
          <li>Fixed‑time quotes & on‑chain verification link</li>
          <li>Optional custody through your family office</li>
        </ul>
        <p className="text-xs text-ash mt-6">Note: Availability may vary by destination and supplier. All payments are subject to KYC/AML review.</p>
      </div>
    </div>
  )
}
