import FeaturedMap from '../../components/FeaturedMap'

export const metadata = {
  title: 'Interactive Map — THE MARQUE'
}

export default function DestinationsPage(){
  return (
    <div className="container-luxe">
      <div className="text-center max-w-3xl mx-auto mb-8">
        <div className="kicker mt-12">Explore</div>
        <h1 className="text-4xl font-display mt-3">Interactive Map</h1>
        <p className="text-ash mt-4">Click pins to open Experiences linked to each location.</p>
      </div>
      <FeaturedMap />
    </div>
  )
}
