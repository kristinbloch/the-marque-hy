export const metadata = { title: 'Contact — THE MARQUE' }
export default function ContactPage(){
  return (
    <div className="container-luxe">
      <div className="max-w-3xl mx-auto mt-12 card p-8">
        <div className="kicker">Contact</div>
        <h1 className="text-4xl font-display mt-3">Plan Your Next Journey</h1>
        <form className="mt-6 grid gap-4">
          <input className="border border-champagne rounded-xl p-3 bg-white" placeholder="Full name" required/>
          <input className="border border-champagne rounded-xl p-3 bg-white" type="email" placeholder="Email" required/>
          <input className="border border-champagne rounded-xl p-3 bg-white" placeholder="Phone"/>
          <textarea className="border border-champagne rounded-xl p-3 bg-white" rows={5} placeholder="Tell us about your trip" />
          <button className="btn-primary w-fit">Send</button>
        </form>
        <p className="text-xs text-ash mt-3">This form is static; connect your preferred form provider or serverless function for live submissions.</p>
      </div>
    </div>
  )
}
