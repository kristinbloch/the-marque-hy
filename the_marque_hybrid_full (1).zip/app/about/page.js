export const metadata = { title: 'About — THE MARQUE' }
export default function AboutPage(){
  return (
    <div className="container-luxe">
      <div className="max-w-3xl mx-auto mt-12">
        <div className="kicker">Our Philosophy</div>
        <h1 className="text-4xl font-display mt-3">Professional Luxury Travellers</h1>
        <p className="text-ash mt-4">We craft journeys with an editorial eye and a concierge’s discretion. Our team are travellers first—curators who know when to open a side door and when to leave space for serendipity.</p>
      </div>
    </div>
  )
}
