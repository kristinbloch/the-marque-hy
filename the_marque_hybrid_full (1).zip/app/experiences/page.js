import Link from 'next/link'
import { getAllPosts } from '../../lib/posts'

export const metadata = {
  title: 'Experiences from Around the World — THE MARQUE'
}

export default function ExperiencesPage(){
  const posts = getAllPosts()
  return (
    <div className="container-luxe">
      <div className="text-center max-w-3xl mx-auto mb-10">
        <div className="kicker mt-12">Experiences</div>
        <h1 className="text-4xl font-display mt-3">Experiences from Around the World</h1>
        <p className="text-ash mt-4">Stories by our Professional Luxury Travellers and clients. Each entry supports up to 4 images and ~350 words.</p>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {posts.map(p => (
          <Link key={p.slug} href={`/experiences/${p.slug}`} className="card overflow-hidden group">
            <img src={p.images?.[0] || '/logo.svg'} alt="" className="w-full h-48 object-cover group-hover:scale-[1.02] transition" />
            <div className="p-6">
              <div className="kicker">{p.location?.label || 'Experience'}</div>
              <div className="mt-2 text-lg font-medium">{p.title}</div>
              <div className="text-sm text-ash mt-1">{p.excerpt}</div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  )
}
