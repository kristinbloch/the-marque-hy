import { notFound } from 'next/navigation'
import { getPostBySlug } from '../../../lib/posts'

export async function generateStaticParams(){
  // Next export needs static params at build time; we can load JSON here
  const { default: all } = await import('../../../content/posts.json')
  return all.map(p=>({ slug: p.slug }))
}

export default async function Experience({ params }){
  const { default: all } = await import('../../../content/posts.json')
  const post = all.find(p=>p.slug===params.slug)
  if(!post) return notFound()

  return (
    <div className="container-luxe">
      <div className="max-w-3xl mx-auto">
        <div className="kicker mt-12">{post.location?.label}</div>
        <h1 className="text-4xl font-display mt-3">{post.title}</h1>
        <p className="text-ash mt-2">{new Date(post.date).toLocaleDateString()}</p>

        <div className="grid sm:grid-cols-2 gap-4 mt-6">
          {(post.images || []).slice(0,4).map((src,i)=>(
            <img key={i} src={src} alt="" className="w-full h-64 object-cover rounded-xl" />
          ))}
        </div>

        <article className="prose prose-lg mt-8 max-w-none">
          <p>{post.content}</p>
        </article>
      </div>
    </div>
  )
}
