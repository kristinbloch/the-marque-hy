'use client'
import { useEffect, useState } from 'react'
import postsData from '../../content/posts.json'

export default function AdminPage(){
  const [posts, setPosts] = useState(postsData)
  const [draft, setDraft] = useState({slug:'', title:'', excerpt:'', date:'', author:'Professional Luxury Traveller', images:[], location:{label:'',lat:'',lng:''}, content:''})

  useEffect(()=>{
    const saved = localStorage.getItem('tm_posts')
    if(saved) setPosts(JSON.parse(saved))
  },[])

  useEffect(()=>{
    localStorage.setItem('tm_posts', JSON.stringify(posts))
  },[posts])

  const addImage = () => {
    if(draft.images.length>=4) return
    setDraft({...draft, images:[...draft.images, '/samples/placeholder.jpg']})
  }

  const savePost = (e) => {
    e.preventDefault()
    const clean = {...draft, lat: undefined, lng: undefined}
    clean.location = { label: draft.location.label, lat: Number(draft.location.lat), lng: Number(draft.location.lng) }
    setPosts([clean, ...posts])
    setDraft({slug:'', title:'', excerpt:'', date:'', author:'Professional Luxury Traveller', images:[], location:{label:'',lat:'',lng:''}, content:''})
  }

  const exportJSON = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(posts, null, 2))
    const a = document.createElement('a')
    a.href = dataStr
    a.download = 'posts.json'
    a.click()
  }

  const importJSON = (e) => {
    const file = e.target.files[0]
    if(!file) return
    const reader = new FileReader()
    reader.onload = evt => {
      try { setPosts(JSON.parse(evt.target.result)) } catch(err){ alert('Invalid JSON') }
    }
    reader.readAsText(file)
  }

  return (
    <div className="container-luxe">
      <div className="max-w-4xl mx-auto mt-12">
        <h1 className="text-3xl font-display">Admin — Local Drafts</h1>
        <p className="text-ash mt-2 text-sm">This is an unprotected local editor. Changes are saved in your browser only. Use Export/Import to update the repository’s <code>content/posts.json</code>.</p>

        <div className="card p-6 mt-6">
          <form onSubmit={savePost} className="grid gap-3">
            <input className="border border-champagne rounded-xl p-3 bg-white" placeholder="Slug (e.g. amalfi-coast-summer)" value={draft.slug} onChange={e=>setDraft({...draft, slug:e.target.value})} required/>
            <input className="border border-champagne rounded-xl p-3 bg-white" placeholder="Title" value={draft.title} onChange={e=>setDraft({...draft, title:e.target.value})} required/>
            <input className="border border-champagne rounded-xl p-3 bg-white" placeholder="Excerpt" value={draft.excerpt} onChange={e=>setDraft({...draft, excerpt:e.target.value})} required/>
            <input className="border border-champagne rounded-xl p-3 bg-white" type="date" value={draft.date} onChange={e=>setDraft({...draft, date:e.target.value})} required/>
            <input className="border border-champagne rounded-xl p-3 bg-white" placeholder="Location label" value={draft.location.label} onChange={e=>setDraft({...draft, location:{...draft.location, label:e.target.value}})} />
            <div className="grid grid-cols-2 gap-3">
              <input className="border border-champagne rounded-xl p-3 bg-white" placeholder="Latitude" value={draft.location.lat} onChange={e=>setDraft({...draft, location:{...draft.location, lat:e.target.value}})} />
              <input className="border border-champagne rounded-xl p-3 bg-white" placeholder="Longitude" value={draft.location.lng} onChange={e=>setDraft({...draft, location:{...draft.location, lng:e.target.value}})} />
            </div>
            <textarea className="border border-champagne rounded-xl p-3 bg-white" rows={6} placeholder="Content (~350 words)" value={draft.content} onChange={e=>setDraft({...draft, content:e.target.value})} />
            <div>
              <button type="button" onClick={addImage} className="btn-primary mr-3">Add Placeholder Image (max 4)</button>
              <span className="text-xs text-ash">Images array: {draft.images.length}/4</span>
            </div>
            <button className="btn-primary w-fit mt-2">Save Post to Local Drafts</button>
          </form>
        </div>

        <div className="flex gap-3 mt-4">
          <button onClick={exportJSON} className="btn-primary">Export posts.json</button>
          <label className="btn border border-champagne rounded-full px-5 py-3 cursor-pointer">
            Import posts.json
            <input type="file" className="hidden" accept=".json,application/json" onChange={importJSON}/>
          </label>
        </div>

        <div className="mt-8">
          <h2 className="text-xl font-semibold">Current Posts</h2>
          <pre className="bg-white border border-champagne rounded-xl p-4 overflow-auto text-xs mt-2">{JSON.stringify(posts,null,2)}</pre>
        </div>
      </div>
    </div>
  )
}
