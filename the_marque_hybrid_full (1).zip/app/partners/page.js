import partners from '../../content/partners.json'
import PartnerGrid from '../../components/PartnerGrid'

export const metadata = {
  title: 'Preferred Partners — THE MARQUE'
}

export default function PartnersPage(){
  return (
    <div className="container-luxe">
      <div className="max-w-4xl mx-auto mt-12">
        <div className="kicker">Network</div>
        <h1 className="text-4xl font-display mt-3">Preferred Partners</h1>
        <p className="text-ash mt-4">Hover over each partner to view membership perks. Perks vary by property and availability.</p>
        <div className="mt-8">
          <PartnerGrid partners={partners} />
        </div>
      </div>
    </div>
  )
}
