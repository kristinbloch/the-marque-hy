import './globals.css'
import Link from 'next/link'

export const metadata = {
  title: 'THE MARQUE — Professional Luxury Travellers',
  description: 'Bespoke travel for UHNW and HNW clients: discreet, story-led itineraries and privileged access.',
  metadataBase: new URL('https://example.com'),
  openGraph: {
    title: 'THE MARQUE',
    description: 'Experiences from Around the World by Professional Luxury Travellers',
    type: 'website'
  },
  twitter: {
    card: 'summary_large_image',
    title: 'THE MARQUE',
    description: 'Bespoke travel for UHNW and HNW clients.'
  }
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        <header className="container-luxe py-6 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3">
            <img src="/logo.svg" alt="THE MARQUE" className="h-10 w-auto" />
          </Link>
          <nav className="flex gap-6 text-sm">
            <Link href="/experiences" className="hover:opacity-70">Experiences</Link>
            <Link href="/destinations" className="hover:opacity-70">Interactive Map</Link>
            <Link href="/membership" className="hover:opacity-70">Membership</Link>
            <Link href="/crypto-travel" className="hover:opacity-70">Crypto Travel</Link>
            <Link href="/partners" className="hover:opacity-70">Preferred Partners</Link>
            <Link href="/about" className="hover:opacity-70">About</Link>
            <Link href="/contact" className="hover:opacity-70">Contact</Link>
            <Link href="/admin" className="hover:opacity-70">Admin</Link>
          </nav>
        </header>
        <main className="min-h-[70vh]">{children}</main>
        <footer className="border-t border-champagne mt-16">
          <div className="container-luxe py-10 grid md:grid-cols-3 gap-8 items-center">
            <div>
              <div className="kicker">THE MARQUE</div>
              <p className="text-sm mt-2">Professional Luxury Travellers — Discretion. Access. Story-led journeys.</p>
              <p className="text-xs mt-4">TICO # <span id="tico-number">XXXXX</span></p>
            </div>
            <div className="md:col-span-2">
              <div className="kicker mb-4">Preferred Partners</div>
              <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-4">
                {['belmond','four_seasons','aman','rosewood','oetker','ritz-carlton','mandarin_oriental'].map((b)=>(
                  <img key={b} src={`/logos/${b}.svg`} alt={b} className="h-10 w-auto opacity-80 hover:opacity-100 transition" />
                ))}
              </div>
            </div>
          </div>
          <div className="text-center text-xs pb-8 opacity-70">© {new Date().getFullYear()} THE MARQUE. All rights reserved.</div>
        </footer>
      </body>
    </html>
  )
}
