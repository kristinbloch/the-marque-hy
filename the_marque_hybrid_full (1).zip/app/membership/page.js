export const metadata = {
  title: 'Membership — THE MARQUE'
}
export default function MembershipPage(){
  return (
    <div className="container-luxe">
      <div className="max-w-4xl mx-auto mt-12 card p-8">
        <div className="kicker">Membership</div>
        <h1 className="text-4xl font-display mt-3">The Marque Membership</h1>
        <p className="text-ash mt-4">An annual, invitation‑only concierge relationship for families and executives who value discretion, velocity, and insider access. Benefits include priority research and holds, bespoke trip architecture, privileged partner amenities, and white‑glove changes while you travel.</p>

        <div className="grid md:grid-cols-3 gap-6 mt-8">
          <div><div className="font-semibold">Privileges</div><ul className="list-disc list-inside text-ash mt-2">
            <li>Dedicated Professional Luxury Traveller</li>
            <li>Priority planning windows & waitlist management</li>
            <li>Exclusive partner benefits & upgrades (when available)</li>
            <li>After‑hours support while in destination</li>
          </ul></div>
          <div><div className="font-semibold">Deliverables</div><ul className="list-disc list-inside text-ash mt-2">
            <li>Annual travel roadmap & quarterly reviews</li>
            <li>Curated shortlist proposals & air/ground coordination</li>
            <li>On‑trip concierge & dining access</li>
            <li>Post‑trip VIP recaps and asset sharing</li>
          </ul></div>
          <div><div className="font-semibold">Fees</div><ul className="list-disc list-inside text-ash mt-2">
            <li>Annual retainer from $X,XXX</li>
            <li>Expedite fees for <em>within 7 days</em> departures</li>
            <li>Custom corporate/family office packages</li>
          </ul></div>
        </div>

        <div className="mt-8 text-sm text-ash">This page is a sample structured on our aesthetic and voice. Replace fee placeholders with your exact terms.</div>
      </div>
    </div>
  )
}
