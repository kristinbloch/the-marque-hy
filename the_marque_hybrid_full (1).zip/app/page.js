import Link from 'next/link'
import FeaturedMap from '../components/FeaturedMap'
import { getAllPosts } from '../lib/posts'

export default function Home() {
  const posts = getAllPosts().slice(0,3)
  return (
    <div className="container-luxe space-y-12">
      <section className="hero p-12 md:p-16">
        <div className="max-w-3xl">
          <div className="kicker">Bespoke Travel</div>
          <h1 className="mt-3 text-4xl md:text-6xl font-display">Romantic Modern Editorial, Story‑Led</h1>
          <p className="mt-6 text-white/80 max-w-2xl">Private access and cinematic itineraries crafted by our Professional Luxury Travellers for UHNW families and discerning explorers.</p>
          <div className="mt-8 flex gap-4">
            <Link href="/experiences" className="btn-primary">Experiences from Around the World</Link>
            <Link href="/destinations" className="btn border border-champagne text-white hover:bg-white hover:text-primary transition">Interactive Map</Link>
          </div>
        </div>
      </section>

      <section>
        <div className="flex items-end justify-between">
          <h2 className="text-2xl font-display">Featured Destinations</h2>
          <Link className="text-sm underline" href="/destinations">Explore the map</Link>
        </div>
        <div className="mt-6">
          <FeaturedMap />
        </div>
      </section>

      <section>
        <div className="flex items-end justify-between">
          <h2 className="text-2xl font-display">Latest Experiences</h2>
          <Link className="text-sm underline" href="/experiences">View all</Link>
        </div>
        <div className="grid md:grid-cols-3 gap-6 mt-6">
          {posts.map(p => (
            <Link key={p.slug} href={`/experiences/${p.slug}`} className="card overflow-hidden group">
              <img src={p.images?.[0] || '/logo.svg'} alt="" className="w-full h-48 object-cover group-hover:scale-[1.02] transition" />
              <div className="p-6">
                <div className="kicker">{p.location?.label || 'Experience'}</div>
                <div className="mt-2 text-lg font-medium">{p.title}</div>
                <div className="text-sm text-ash mt-1">{p.excerpt}</div>
              </div>
            </Link>
          ))}
        </div>
      </section>
    </div>
  )
}
