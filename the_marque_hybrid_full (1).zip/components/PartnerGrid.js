'use client'
export default function PartnerGrid({ partners }){
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-6">
      {partners.map(p => (
        <div key={p.id} className="relative group card p-6 flex items-center justify-center">
          <img src={p.logo} alt={p.name} className="h-12 w-auto opacity-90 group-hover:opacity-100 transition"/>
          <div className="absolute inset-0 hidden group-hover:flex items-end">
            <div className="m-3 p-4 bg-primary text-white rounded-xl shadow-luxe text-xs">
              <div className="font-semibold text-sm">{p.name}</div>
              <div className="opacity-90 mt-1">{p.perks}</div>
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}
