'use client'
import Link from 'next/link'
import { useMemo } from 'react'
import { getAllPosts } from '../lib/posts'

export default function FeaturedMap() {
  const posts = getAllPosts()
  const pins = useMemo(()=>posts.map(p=>({slug:p.slug, title:p.title, lat:p.location?.lat, lng:p.location?.lng})).filter(p=>p.lat && p.lng)),[posts])

  // simple SVG map with equirectangular projection (approximate)
  const width = 900, height = 450
  const project = (lng, lat) => {
    const x = (lng + 180) * (width / 360)
    const y = (90 - lat) * (height / 180)
    return [x,y]
  }

  return (
    <div className="relative card overflow-hidden">
      <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto">
        <rect width={width} height={height} fill="#F7F3ED"/>
        <g opacity="0.08">
          <rect width={width} height={height} fill="#0F172A"/>
        </g>
        {/* Very minimal land silhouettes */}
        <g fill="#D4C6A7" opacity="0.35">
          <ellipse cx="220" cy="160" rx="180" ry="110"/>
          <ellipse cx="540" cy="180" rx="220" ry="120"/>
          <ellipse cx="750" cy="320" rx="120" ry="80"/>
          <ellipse cx="120" cy="300" rx="120" ry="70"/>
        </g>
        {pins.map((p,i)=>{
          const [x,y] = project(p.lng, p.lat)
          return (
            <Link href={`/experiences/${p.slug}`} key={i}>
              <g>
                <circle cx={x} cy={y} r="6" fill="#D4C6A7" stroke="#0F172A" strokeWidth="2"/>
                <text x={x+10} y={y-10} fontSize="11" fill="#0F172A">{p.title}</text>
              </g>
            </Link>
          )
        })}
      </svg>
      <div className="absolute inset-x-0 bottom-0 p-4 text-right text-xs text-ash">Click a pin to open the experience</div>
    </div>
  )
}
