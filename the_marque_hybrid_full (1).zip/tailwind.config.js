/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./app/**/*.{js,ts,jsx,tsx}','./components/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: '#0F172A', // deep navy
        champagne: '#D4C6A7',
        onyx: '#0B0B0C',
        ash: '#4B5563',
        parchment: '#F7F3ED'
      },
      fontFamily: {
        display: ['ui-serif','Georgia','serif'],
        body: ['ui-sans-serif','system-ui','-apple-system','Segoe UI','Roboto','Helvetica','Arial']
      },
      boxShadow: {
        luxe: '0 10px 30px rgba(0,0,0,0.15)'
      },
      borderRadius: {
        '2xl': '1rem'
      }
    },
  },
  plugins: [],
}
