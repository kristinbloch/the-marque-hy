import Header from '../components/Header'
import Footer from '../components/Footer'

export default function Membership(){
  return (
    <div>
      <Header />
      <main className="max-w-5xl mx-auto p-8">
        <h1 className="text-4xl font-serif mb-6">Membership at The Marque</h1>
        <p className="text-gray-700 mb-8">An invitation to The Marque is an entrée into a world of private journeys and privileged access. Below are highlights of our premier partnerships.</p>
        <section className="mb-12">
          <h2 className="text-2xl font-serif mb-4">Belmond Bellini Club</h2>
          <ul className="list-disc pl-6 text-gray-700">
            <li>VIP recognition & welcome amenities</li>
            <li>Complimentary upgrade on arrival (when available)</li>
            <li>Priority waitlist clearance</li>
          </ul>
        </section>
        <section className="mb-12">
          <h2 className="text-2xl font-serif mb-4">Four Seasons Preferred Partner</h2>
          <ul className="list-disc pl-6 text-gray-700">
            <li>Daily breakfast for two</li>
            <li>Upgrade on arrival (subject to availability)</li>
            <li>Early check-in / late check-out</li>
          </ul>
        </section>
        <section className="mb-12">
          <h2 className="text-2xl font-serif mb-4">Marriott STARS (Ritz-Carlton & St. Regis)</h2>
          <ul className="list-disc pl-6 text-gray-700">
            <li>Exclusive STARS amenities</li>
            <li>Personalized welcome & recognition</li>
            <li>Special experiences curated for members</li>
          </ul>
        </section>
        <section className="mb-12">
          <h2 className="text-2xl font-serif mb-4">Relais & Châteaux</h2>
          <ul className="list-disc pl-6 text-gray-700">
            <li>Breakfast for two</li>
            <li>Potential room upgrade</li>
            <li>VIP recognition at participating properties</li>
          </ul>
        </section>
        <p className="mt-12 italic text-gray-700">Membership is by invitation or approved request. Additional benefits available to members upon login.</p>
      </main>
      <Footer />
    </div>
  )
}
