import { useRouter } from 'next/router'
import Header from '../../components/Header'
import Footer from '../../components/Footer'
import { useEffect, useState } from 'react'

export default function TripReport(){
  const router = useRouter()
  const { id } = router.query
  const [trip, setTrip] = useState(null)

  useEffect(()=>{
    if(!id) return
    fetch('/api/trips').then(r=>r.json()).then(list=>{
      const t = list.find(x=>String(x.id)===String(id))
      setTrip(t)
    })
  },[id])

  if(!trip) return (
    <div>
      <Header />
      <main className="max-w-4xl mx-auto p-6">Loading…</main>
      <Footer />
    </div>
  )

  return (
    <div>
      <Header />
      <main className="max-w-4xl mx-auto p-6">
        <h1 className="text-3xl font-serif mb-4">{trip.title}</h1>
        <p className="text-sm text-gray-600 mb-6">By {trip.agent} — {trip.date}</p>
        <img src={trip.photo} className="w-full h-72 object-cover rounded-lg mb-6"/>
        <div className="prose max-w-none" dangerouslySetInnerHTML={{__html: trip.reportHtml}} />
      </main>
      <Footer />
    </div>
  )
}
