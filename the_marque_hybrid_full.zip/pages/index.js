import Header from '../components/Header'
import Footer from '../components/Footer'
import Hero from '../components/Hero'
import PartnerCard from '../components/PartnerCard'

export default function Home(){
  return (
    <div>
      <Header />
      <main className="max-w-7xl mx-auto px-6">
        <Hero title="Exclusivity Redefined" subtitle="Purely bespoke travel for those who seek the unseen." ctas={<>
          <a href="/membership" className="px-5 py-3 bg-gold rounded-md font-medium">Request Membership</a>
          <a href="/destinations" className="px-5 py-3 border rounded-md">Explore Destinations</a>
        </>} />
        <section className="grid grid-cols-3 gap-6 mt-8">
          <PartnerCard title="Belmond - Bellini Club" description="Preferred access and curated experiences" href="#" />
          <PartnerCard title="Four Seasons - Preferred" description="Priority availability at top properties" href="#" />
          <PartnerCard title="Ritz-Carlton - STARS" description="Exclusive amenities & upgrades" href="#" />
        </section>
      </main>
      <Footer />
    </div>
  )
}
