import Header from '../components/Header'
import Footer from '../components/Footer'
import dynamic from 'next/dynamic'
const MapViewer = dynamic(()=>import('../components/MapViewer'), { ssr:false })

export default function MapPage(){
  return (
    <div>
      <Header />
      <main className="max-w-7xl mx-auto px-6 py-12">
        <h2 className="text-3xl font-serif mb-6">Agent Trip Map</h2>
        <p className="text-gray-600 mb-6">Explore recent stories — click a pin to read the trip report and see curated photos.</p>
        <MapViewer />
      </main>
      <Footer />
    </div>
  )
}
