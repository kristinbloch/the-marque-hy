import { useState } from 'react'
import { useRouter } from 'next/router'
import Header from '../components/Header'
import Footer from '../components/Footer'

export default function Login(){
  const [email, setEmail] = useState('')
  const [pass, setPass] = useState('')
  const router = useRouter()

  async function submit(e){
    e.preventDefault()
    const res = await fetch('/api/auth', { method:'POST', headers:{'content-type':'application/json'}, body: JSON.stringify({email, pass})})
    if(res.ok) router.push('/dashboard')
  }

  return (
    <div>
      <Header />
      <main className="max-w-2xl mx-auto p-6">
        <h2 className="text-2xl font-serif mb-4">Member Login</h2>
        <form onSubmit={submit} className="space-y-4">
          <input className="w-full border p-3 rounded" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
          <input className="w-full border p-3 rounded" placeholder="Password" type="password" value={pass} onChange={e=>setPass(e.target.value)} />
          <button className="px-6 py-3 bg-matte-black text-white rounded">Log In</button>
        </form>
      </main>
      <Footer />
    </div>
  )
}
