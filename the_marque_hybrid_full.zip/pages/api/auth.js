// Mock auth — replace in production
import jwt from 'jsonwebtoken'
export default function handler(req, res){
  if(req.method==='POST'){
    const { email } = req.body
    const token = jwt.sign({ email }, 'demo-secret', { expiresIn: '7d' })
    res.status(200).json({ token })
  } else res.status(405).end()
}
