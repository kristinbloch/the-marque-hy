// Demo UHNW stories for map pins
const trips = [
  {
    id: 1,
    title: 'A Venetian Evening with Belmond',
    summary: 'A private palazzo dinner, serenaded by strings on the Grand Canal.',
    agent: 'Clara M., Art Patron from London',
    date: '2025-07-12',
    lat: 45.4408,
    lng: 12.3155,
    photo: '/trip-venice.jpg',
    reportHtml: `<p>As dusk fell over Venice, The Marque secured for us a private palazzo dinner overlooking the Grand Canal. A quartet of strings played softly as we dined by candlelight — the city felt like ours alone.</p>
      <h3>Highlights</h3>
      <ul><li>Personal gondola route, far from the crowds.</li><li>Bellini Club perks at Belmond Cipriani.</li><li>Hermès amenity gifts awaiting in-suite.</li></ul>
      <blockquote>“This was Venice as few will ever see it — discreet, romantic, and unforgettable.”</blockquote>`
  },
  {
    id: 2,
    title: 'Four Seasons Tokyo — Urban Sanctuaries',
    summary: 'From our sky‑high suite, Tokyo stretched endlessly — yet serenity was at hand.',
    agent: 'Alexander R., Private Equity Partner, New York',
    date: '2025-06-03',
    lat: 35.6762,
    lng: 139.6503,
    photo: '/trip-tokyo.jpg',
    reportHtml: `<p>The Marque curated our stay at Four Seasons Tokyo with precision. Between private dining with a Michelin‑starred chef and access to ateliers normally closed to the public, it was Tokyo distilled to pure privilege.</p>
      <h3>Highlights</h3>
      <ul><li>Preferred Partner benefits at Four Seasons Otemachi.</li><li>After‑hours gallery tour in Ginza.</li><li>Personal shopping appointment at Comme des Garçons.</li></ul>
      <blockquote>“In the heart of Tokyo, The Marque found us serenity and exclusivity few will ever access.”</blockquote>`
  },
  {
    id: 3,
    title: 'Caribbean Horizons — Ritz-Carlton Yacht',
    summary: 'Cruising azure waters, each port unveiled with private‑club finesse.',
    agent: 'Isabella D., Fashion House Creative Director, Paris',
    date: '2025-05-20',
    lat: 18.2208,
    lng: -66.5901,
    photo: '/trip-caribbean.jpg',
    reportHtml: `<p>The Ritz‑Carlton Yacht was our stage, but The Marque wrote the script. Each island was revealed with quiet opulence: villas hidden from view, chefs flown in for a single evening, champagne picnics on deserted beaches.</p>
      <h3>Highlights</h3>
      <ul><li>STARS benefits with Ritz‑Carlton Yacht Collection.</li><li>Private access to a closed‑door art estate in St. Barts.</li><li>Sunset champagne served on deck, no other yachts in sight.</li></ul>
      <blockquote>“Not once did it feel like travel; it felt like belonging to a world few will ever enter.”</blockquote>`
  }
]

export default function handler(req, res){ res.status(200).json(trips) }
