export default function handler(req, res){
  const partners = [
    { id:1, name:'Virtuoso Member Agency', summary:'Global luxury network with VIP amenities and recognition.', link:'#'},
    { id:2, name:'Forbes Travel', summary:'Recognized as a Forbes Travel agency — access to Forbes-rated hotels.', link:'#'},
    { id:3, name:'Belmond Bellini Club', summary:'Exclusive Bellini Club benefits including VIP amenities and recognition.', link:'#'},
    { id:4, name:'Four Seasons Preferred Partner', summary:'Access to Four Seasons Preferred rates, upgrades, and amenities.', link:'#'},
    { id:5, name:'Relais & Châteaux', summary:'Preferred partner with Relais & Châteaux properties worldwide.', link:'#'},
    { id:6, name:'Rosewood Elite', summary:'Elite recognition with Rosewood hotels and resorts.', link:'#'},
    { id:7, name:'SLH (Small Luxury Hotels of the World)', summary:'Exclusive amenities at SLH boutique properties.', link:'#'},
    { id:8, name:'Design Hotels', summary:'Curated access to unique Design Hotels globally.', link:'#'},
    { id:9, name:'Accor HERA', summary:'Preferred partnership with Accor HERA luxury properties.', link:'#'},
    { id:10, name:'Marriott STARS', summary:'STARS benefits at Ritz-Carlton, St. Regis, and select Marriott luxury brands.', link:'#'},
    { id:11, name:'Hyatt Privé', summary:'Exclusive recognition and benefits at Hyatt Privé properties.', link:'#'},
    { id:12, name:'Mr & Mrs Smith', summary:'Boutique stays with Smith Extras.', link:'#'},
    { id:13, name:'Auberge Resorts Collection', summary:'Exclusive Auberge partner perks.', link:'#'},
    { id:14, name:'Peninsula PenClub', summary:'Preferred Peninsula partnership with elite recognition.', link:'#'},
    { id:15, name:'Dorchester Diamond Club', summary:'Dorchester Collection partner perks and upgrades.', link:'#'}
  ]
  res.status(200).json(partners)
}
