// Simple in-memory request store (demo)
let requests = []
export default function handler(req, res){
  if(req.method==='POST'){
    const body = req.body
    const id = requests.length + 1
    requests.push({ id, ...body, createdAt: new Date().toISOString() })
    return res.status(201).json({ id })
  }
  res.status(200).json(requests)
}
