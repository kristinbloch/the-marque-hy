import Header from '../components/Header'
import Footer from '../components/Footer'
import { useState } from 'react'

export default function Contact(){
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [message, setMessage] = useState('')
  const [sent, setSent] = useState(false)

  async function submit(e){
    e.preventDefault()
    await fetch('/api/requests', {method:'POST', headers:{'content-type':'application/json'}, body: JSON.stringify({name, email, message})})
    setSent(true)
  }

  return (
    <div>
      <Header />
      <main className="max-w-3xl mx-auto p-6">
        <h2 className="text-2xl font-serif mb-4">Contact the Concierge</h2>
        {!sent ? (
          <form onSubmit={submit} className="space-y-4">
            <input className="w-full border p-3 rounded" placeholder="Name" value={name} onChange={e=>setName(e.target.value)} />
            <input className="w-full border p-3 rounded" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
            <textarea className="w-full border p-3 rounded" placeholder="Tell us about your request" value={message} onChange={e=>setMessage(e.target.value)} />
            <button className="px-6 py-3 bg-matte-black text-white rounded">Send Request</button>
          </form>
        ) : (
          <div className="p-6 bg-green-50 rounded">Thanks — a concierge will contact you shortly.</div>
        )}
      </main>
      <Footer />
    </div>
  )
}
