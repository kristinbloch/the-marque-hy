import Header from '../../components/Header'
import Footer from '../../components/Footer'
import useSWR from 'swr'
const fetcher = (url)=>fetch(url).then(r=>r.json())

export default function Dashboard(){
  const { data: partners } = useSWR('/api/partners', fetcher)

  return (
    <div>
      <Header />
      <main className="max-w-6xl mx-auto p-6">
        <h2 className="text-3xl font-serif mb-4">Welcome back, Member</h2>
        <p className="text-gray-600 mb-6">Your exclusive partner programs & curated offers.</p>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
          {partners && partners.map(p=> (
            <div key={p.id} className="p-6 bg-white rounded-xl shadow">
              <h4 className="font-semibold">{p.name}</h4>
              <p className="text-sm text-gray-600 mt-2">{p.summary}</p>
              <a href={p.link} className="mt-4 inline-block text-gold">View Benefits →</a>
            </div>
          ))}
        </div>
      </main>
      <Footer />
    </div>
  )
}
